condition = 1

while condition < 10:
    print(condition)
    condition += 1

while True:
    print('doing stuff')
