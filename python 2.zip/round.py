x = 2.9
print(round(x))
