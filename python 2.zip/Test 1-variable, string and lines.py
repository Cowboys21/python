# changing case
first_name = 'aryan'
print(first_name)
print(first_name.title())
print(first_name.upper())
print(first_name.lower())



# Combining names
first_name = 'Aryan'
last_name = 'Tomar'
full_name = first_name + ' ' + last_name
print(full_name.title())



# white spaces
print("\thello everyone")
# use \t to tab 



# new line
print("\n Hello everyone\n Bye everyone!")
# use \n to create new line



# strip white space
name = '                      Aryan'
print (name)
print(name.lstrip())
# use print.lstrip strip for left strip and print.rstrip right and
# strip for both sides



# different opperations
print(" addition = + ")
print(" subtraction = - ")
print(" multiply = * ")
print(" division = / ")
print(" exponent = ** ")



# parenthesis
Standard = 2+3*4**9
print (Standard)
Parenthesis = (2+3)*4**9
print(Parenthesis)



# floats
print(0.1 + 0.2)
print("the randoom .00000000000000004 decimal happens because of the way computers represent numbers internally")
print("this has nothing to do with Python itself.")
print("Basically, we are used to working in powers of ten, where one tenth plus two tenths is just three tenths.")
print("But computers work in powers of two.")
