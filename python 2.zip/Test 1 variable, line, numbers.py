# Combining names
first_name = 'Aryan'
last_name = 'Tomar'

full_name = first_name + ' ' + last_name
print(full_name.title())

# white spaces

print("\thello everyone")
# use \t to tab 
