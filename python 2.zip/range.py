for i in range(0,101):
    if i%2 == 0:
        print (i)

