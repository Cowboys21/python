import math

print(math.ceil(8.1))
print(abs(-2.9))
