What_is_name = input('What_is_name: ')
print(type(What_is_name))



criminal_record = input('criminal_record: ')
print(type(criminal_record))



