
X = input('what is your anual sallary?  ')
if X >= '50000':
   you_are_rich = True
else :
   you_are_rich = False

if you_are_rich == True :


    print("you  are rich")
else :


    print("you are broke loser")

