

print('o----')
print(' ||||')
print('*'*10)
print('hi'*10)
price = 10
price = 20
rating = 4.9
name = 'Aryan'
is_published = True
print(price)
name = 'John Smith'
age = 20
is_new = True
print(age)
name = input('What is your name?  ')
favorite_color=input('What is your favorite color? ')
print(name + ' likes ' + favorite_color)
