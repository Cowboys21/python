print("I am going to ask for your height in feet and am going to convert it in"+
      " inches.")



what_height = input('What is your height in feet?(round to the nearest foot): ')
print(type(what_height))
inches = 12 * int(what_height)
print(type(inches))
print(inches)
