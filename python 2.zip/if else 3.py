X = 'Aarshabh is smart'
Y = 'Aarshabh is the best'
Z = 'Aarshabh is dumb'
A = 'Aarshabh is smart'

if X == A:
    print('Aarshabh is smart')
elif Y == A:
    ('Aarshabh is the best')
else:
    print('Aarshabh is dumb')
