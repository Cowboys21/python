x = 5
y = 10
z = 22
if x > y:
    print('X is greater than y')
else:
    print('Y is greater than X')

    
    
