mood="overrjoyed"
print(f"I'm so {mood} to be learning Python!")
multiline_sentence="""
Here is
a sentence
on many
different lines
"""
print(f"{multiline_sentences}")
