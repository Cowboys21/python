course = 'python for beginners'
print(len(course))
print(course.lower())
print(course.upper())
print(course.replace('begginers','absolute beginners'))
course.find('python')
print(10%3)
x = 10
x = x + 3
print(x)
x += 3
print(x)
