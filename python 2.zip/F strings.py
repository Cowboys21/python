name = 'Aryan'

print('My name is {}'.format(name))

print(f'My name is {name}')
