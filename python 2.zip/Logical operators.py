has_high_income = True
has_good_credit = True

if has_high_income or has_good_credit:
    print("Eligable for loan")

has_good_credit = True
X = False

if has_good_credit and not X:
    print("Eligible for loan")


