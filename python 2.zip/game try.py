secret_number = 9
i = 0
while i < 3:
