Python 3.7.4 (tags/v3.7.4:e09359112e, Jul  8 2019, 19:29:22) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
======== RESTART: C:/Users/tomar/Desktop/Aryan Python/First python.py ========
hi python
Aarshabh is stupid
I'm super happy
"Namste" is "hello" in Hindi!
>>> hi
Traceback (most recent call last):
  File "<pyshell#0>", line 1, in <module>
    hi
NameError: name 'hi' is not defined
>>> (" Here is \na sentence \non many \ndifferent lines")
' Here is \na sentence \non many \ndifferent lines'
>>> name='Aryan da gawd'
>>> print(name)
Aryan da gawd
>>> 
>>>  favorite_number=3
 
SyntaxError: unexpected indent
>>> 
>>> favorite_number=16
>>> type(favorite_number)
<class 'int'>
>>> type(name)
<class 'str'>
>>> 10name= Aryan
SyntaxError: invalid syntax
>>> 10name='aryan'
SyntaxError: invalid syntax
>>> firstName'aryan'
SyntaxError: invalid syntax
>>> firstName='Aryan'
>>> numberOfCookies=2
>>> FirstName='Aryan'
>>> NumberOfCookies=2
>>> mood='happy'
>>> age=10
>>> favorite_color='blue'
>>> number_of_books=4
>>> 
======= RESTART: C:/Users/tomar/Desktop/Aryan Python/learning moods.py =======
I'm so overrjoyed to be learning Python!
>>> 
======= RESTART: C:/Users/tomar/Desktop/Aryan Python/learning moods.py =======
I'm so overrjoyed to be learning Python!
Traceback (most recent call last):
  File "C:/Users/tomar/Desktop/Aryan Python/learning moods.py", line 9, in <module>
    print(f"{multiline_sentences}")
NameError: name 'multiline_sentences' is not defined
>>> 
======= RESTART: C:/Users/tomar/Desktop/Aryan Python/learning moods.py =======
I'm so overrjoyed to be learning Python!
Traceback (most recent call last):
  File "C:/Users/tomar/Desktop/Aryan Python/learning moods.py", line 9, in <module>
    print(f"{multiline_sentences}")
NameError: name 'multiline_sentences' is not defined
>>> my_gpa = 3.47
>>> type(my_gpa)
<class 'float'>
>>> my_score = 3000
>>> type(my_score)
<class 'int'>
>>> a=6
>>> b = 3
>>> a = 6
>>> a - b
3
>>> a x b
SyntaxError: invalid syntax
>>> a * b
18
>>> b  / a
0.5
>>> b/a
0.5
>>> a+b
9
>>> a = 9000
>>> b = 8000
>>> a+b
17000
>>> a*b
72000000
>>> a=900000
>>> b=800000
>>> a+b
1700000
>>> a*b
720000000000
>>> 72000000
72000000
>>> a**b

=============================== RESTART: Shell ===============================
>>> total=20+(20*1.82)-2.5+3**2
>>> print(total)
62.9
>>> 3>7
False
>>> 3<7
True
>>> 999999999999999999999999999999999999>99999999999999999999999999999999999999
False
>>> 999999999999999999999999999999999999999999>999999999999999999999999999999999999999
True
>>> 4>=3
True
>>> 8<=
SyntaxError: invalid syntax
>>> 8<=7
False
>>> 21==21
True
>>> 10=10
SyntaxError: can't assign to literal
>>> 10=="10"
False
>>> 3!=4
True
>>> is x > y:
	
SyntaxError: invalid syntax
>>> if x > y :
	print x is greater than y
	
SyntaxError: Missing parentheses in call to 'print'. Did you mean print(x is greater than y)?
>>> if x > y :
	print x is greater than y
	
SyntaxError: Missing parentheses in call to 'print'. Did you mean print(x is greater than y)?
>>> if x > y
SyntaxError: invalid syntax
>>> if X is > Y:
	
SyntaxError: invalid syntax
>>> if x>y
SyntaxError: invalid syntax
>>> ifx>y:
	
SyntaxError: invalid syntax
>>> if x > y
SyntaxError: invalid syntax
>>> if X > y:
	print('x is greater than y')
else:
	print('x is not greater than y')
