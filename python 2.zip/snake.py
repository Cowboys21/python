import turtle

# Set up screen
wn = turtle.Screen
wn.title("Snake Game by @Xx2sway")
wn.bgcolor("red")
wn.setup(width=600, height=600
wn.tracer(0)



wn.mainloop
