birth_year = input('Birth year: ')
print(type(birth_year))
age = 2020 - int(birth_year)
print(type(age))
print(age)

pounds = input('pounds: ')
kilograms = .45 * int(pounds)
print(kilograms)
course = "Pythons course for beginners"
print(course[:])
