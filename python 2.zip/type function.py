type(20)
type("hello")
