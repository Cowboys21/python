mood="delighted"
print("hi python")
print("Aarshabh is stupid")
print("I'm super happy")
print("\"Namste\" is \"hello\" in Hindi!"
print(f"I'm so {mood} to be learning how to code with python")
print("I am very {mood}")
