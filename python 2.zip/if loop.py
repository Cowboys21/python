x = 5
y = 8
z = 5
a = 3

if z <= x:
    print('z is less than or equal to x')

if z < y > x > a:
    print('y is greater than z and greater than x')

if x < y:
    print('x is less that y')
