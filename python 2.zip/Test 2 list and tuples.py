# creating list
dogs = ['border collie', 'australian cattle dog', 'labrador retriever']



# Accessing one item
dog = dogs[0]
print(dog.title())
# the index of an item is always one less than its position in the list.
dogo = dogs[-1]
print(dogo)
# use "-" to use last things on list



# Access all elements in list
for dog in dogs:
    print(dog)




#loop notes
#"for" tells Python to get ready to use a loop.




# adding things inside loop
for dog in dogs:
    print('I poop on and love' + dog + 's.')



#inside/outside loop
for dog in dogs:
    print('I like ' + dog + 's.')
    print('No, I really really like ' + dog +'s!\n')
    
print("\nThat's just how I feel about dogs.")




#enumerating lists
#enumerate()function tracks the index of each item
#for you, as it loops through the list
print("Results for the dog show are as follows:\n")
for index, dog in enumerate(dogs):
    place = str(index + 1)
    print("Place: " + place + " Dog: " + dog.title())




#loop practice
sports =['football','basketball','soccer']
for sport in sports:
    print('I like '+ sport) 




#modify element in list
dogs = ['border collie', 'australian cattle dog', 'labrador retriever']
dogs[0] = 'australian shepherd'
print(dogs)



#finding element in a list
print(dogs.index('australian cattle dog'))




#Testing if item is in list
# you can test using the "in" function
print('australian cattle dog' in dogs)
print('poodle' in dogs)



# adding/appending things to list
#append means add on the end of line
dogs.append('ugly german shepard')
for dog in dogs:
    print(dog.title() + "s are cool.")



    
#inserting items
#inserting means you can  add put anywhere in list
dogs.insert(1, 'poop')
print(dogs)




#create empty list
usernames =[]
#how to add items
usernames.append('turd')
usernames.append('poop')
usernames.append('toilet')
#how to use list
for username in usernames:
    print("We need, " + username.title() + '!')
#use user in sentence
print("\nThank you for being our very first user, " + usernames[0].title() + '!')
print("And a warm welcome to our newest user, " + usernames[-1].title() + '!')




#sorting list
#put in alphabetic order
usernames.sort()
#display in order
print("Our students are poops are in alphabetical order.")
for username in usernames:
    print(username.title())
#reverse alphabetical order
usernames.sort(reverse=True)
print("our tutties will now be in reverse")
for username in usernames:
    print(username.title())




#Numerical list
numbers = [2,4,3,1]
#sort numbers
numbers.sort()
print(numbers)
# reverse number list
numbers.sort(reverse=True)
print(numbers)
